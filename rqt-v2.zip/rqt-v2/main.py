from fastapi import FastAPI
from app.controllers import rqt_bff_controller,rqt_run_controller
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(debug=True)

origins = [
    "http://localhost:5173",
    "http://127.0.0.1:5173"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,  # or ["*"] to allow all
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# app.include_router(auth_controller.router, prefix="/v1/auth", tags=["Auth"])
# app.include_router(otp_controller.router, prefix="/v1/otp", tags=["OTP"])

app.include_router(rqt_bff_controller.router, prefix="/rqt-bff/v1", tags=["RQT-BFF"])
app.include_router(rqt_run_controller.router, prefix="/rqt-run/v1", tags=["RQT-RUN"])


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host = "0.0.0.0", port = 8000)