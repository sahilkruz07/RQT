def serialize_testsuite(testsuite: dict) -> dict:
    if testsuite is None:
        return None
    return {**testsuite, "_id": (str(testsuite['_id'])) } if "_id" in testsuite else testsuite
    

def serialize_testsuite_bulk(testsuites: list) -> list:
    return [serialize_testsuite(ts) for ts in testsuites]