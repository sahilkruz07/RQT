def serialize_testcase(testcase: dict) -> dict:
    if testcase is None:
        return None
    return {**testcase, "_id": (str(testcase['_id'])) } if "_id" in testcase else testcase
    

def serialize_testcase_bulk(testcases: list) -> list:
    return [serialize_testcase(tc) for tc in testcases]