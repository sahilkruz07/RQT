def map_required_fields(required_fields, from_dict):
    new_dict = {}
    for field in required_fields:
        if field in from_dict:
            new_dict[field] = from_dict[field]
        else :
            new_dict[field] = None
    return new_dict

