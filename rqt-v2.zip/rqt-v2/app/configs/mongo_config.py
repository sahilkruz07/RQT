import certifi
from motor.motor_asyncio import AsyncIOMotorClient

MONGO_URI = "mongodb://sahilkangane:ML1q8YfTa3nKUpCr@ac-fxzgvcl-shard-00-00.7k3b4pc.mongodb.net:27017,ac-fxzgvcl-shard-00-01.7k3b4pc.mongodb.net:27017,ac-fxzgvcl-shard-00-02.7k3b4pc.mongodb.net:27017/admin?ssl=true&retryWrites=true&replicaSet=atlas-bm0u75-shard-0&readPreference=primary&connectTimeoutMS=10000&authSource=admin&authMechanism=SCRAM-SHA-1"

mongo_client = AsyncIOMotorClient(MONGO_URI, tlsCAFile=certifi.where())

rqt_mongo = mongo_client['rqt']

# Collections
rqt_counter_master = rqt_mongo['rqt_counter_master']

rqt_testcase_master = rqt_mongo['rqt_testcase_master']
rqt_testcase_master_logs = rqt_mongo['rqt_testcase_master_logs']

rqt_workitem_master = rqt_mongo['rqt_workitem_master']
rqt_workitem_master_logs = rqt_mongo['rqt_workitem_master_logs']

rqt_env_config = rqt_mongo['rqt_env_config']
rqt_env_config_logs = rqt_mongo['rqt_env_config_logs']

rqt_testsuite_master = rqt_mongo['rqt_testsuite_master']
rqt_testsuite_master_logs = rqt_mongo['rqt_testsuite_master_logs']

rqt_run_testcase_audit = rqt_mongo['rqt_run_testcase_audit']