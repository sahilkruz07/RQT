from pydantic import BaseModel
from typing import List,Dict,Any,Optional

class RunWorkitemRequest(BaseModel):
    workitem_id : str
    env : str
    workitem_executor_context : str
    workitem_prev_ff : Dict[str, Any]

class RunTestcaseRequest(BaseModel):
    testcase_id : str
    env : str
    testcase_executor_context : str


class RunTestcaseBulkRequest(BaseModel):
    testcase_id_list : List[str]
    env : str
    run_testcase_executor_context : str

