from app.configs.mongo_config import rqt_env_config

async def find_env_config_by_config_key_and_env(config_key : str, env : str):
    return await rqt_env_config.find_one({"config_key": config_key, "env": env})

async def update_to_db(config_key, env, updated_env_config):
    update_data = {
        "$set": updated_env_config 
    }
    await rqt_env_config.update_one({"config_key": config_key, "env": env}, update_data)


async def insert_to_db(env_config):
    await rqt_env_config.insert_one(env_config)
