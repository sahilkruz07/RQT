from app.configs.mongo_config import rqt_testsuite_master

async def find_test_suite_by_testsuite_id_is_deleted(testsuite_id : str, testsuite_is_deleted : bool):
    return await rqt_testsuite_master.find_one({"testsuite_id": testsuite_id, "testsuite_is_deleted": testsuite_is_deleted})


async def insert_to_db(testsuite):
    await rqt_testsuite_master.insert_one(testsuite)


async def update_to_db(testsuite_id,updated_testsuite):
    update_data = {
        "$set": updated_testsuite 
    }
    await rqt_testsuite_master.update_one({"testsuite_id": testsuite_id}, update_data)
