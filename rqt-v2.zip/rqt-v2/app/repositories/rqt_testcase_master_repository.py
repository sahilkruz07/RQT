from app.configs.mongo_config import rqt_testcase_master

async def find_test_case_by_testcase_id_is_deleted(testcase_id : str, testcase_is_deleted : bool):
    return await rqt_testcase_master.find_one({"testcase_id": testcase_id, "testcase_is_deleted": testcase_is_deleted})


async def insert_to_db(testcase):
    await rqt_testcase_master.insert_one(testcase)


async def update_to_db(testcase_id,updated_testcase):
    update_data = {
        "$set": updated_testcase 
    }
    await rqt_testcase_master.update_one({"testcase_id": testcase_id}, update_data)



async def find_testcase_by_search_params_without_search_query(skip:int, page_size :int,sort_by : str, sort_order : int):
    return await rqt_testcase_master.find({"testcase_is_deleted": False}).sort(sort_by,sort_order).skip(skip).limit(page_size).to_list(length=page_size)
