from app.configs.mongo_config import rqt_workitem_master

async def find_workitem_by_workitem_id_is_deleted(workitem_id : str, workitem_is_deleted : bool):
    return await rqt_workitem_master.find_one({"workitem_id": workitem_id, "workitem_is_deleted": workitem_is_deleted})

async def insert_to_db(workitem):
    await rqt_workitem_master.insert_one(workitem)

async def update_to_db(workitem_id,updated_workitem):
    update_data = {
        "$set": updated_workitem 
    }
    await rqt_workitem_master.update_one({"workitem_id": workitem_id}, update_data)

async def find_workitem_by_search_params_without_search_query(skip:int, page_size :int,sort_by : str, sort_order : int):
    return await rqt_workitem_master.find({"workitem_is_deleted": False}).sort(sort_by,sort_order).skip(skip).limit(page_size).to_list(length=page_size)
