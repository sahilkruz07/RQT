from app.services import rqt_util_service
from app.utils.enums import workitem_status_enum
import httpx
from datetime import datetime

async def execute_rest_api(workitem, env, workitem_prev_ff, workitem_logs):
    try :
        workitem_request_params = workitem['workitem_request_params']
        http_method = workitem_request_params['http_method']

        
        match http_method:
            case 'POST':
                workitem_log = {
                    "log_type" : "INFO",
                    "message" : "Executing " + http_method + " API for workitem_id : " + workitem['workitem_id'],
                    "payload" : workitem_request_params['api_endpoint'],
                    "timestamp" : datetime.utcnow()
                } 
                workitem_logs.append(workitem_log)
                return await execute_post_api(workitem, env, workitem_prev_ff, workitem_logs)
            
            case 'GET':
                workitem_log = {
                    "log_type" : "INFO",
                    "message" : "Executing " + http_method + " API for workitem_id : " + workitem['workitem_id'],
                    "payload" : workitem_request_params['api_endpoint'],
                    "timestamp" : datetime.utcnow()
                } 
                workitem_logs.append(workitem_log)
                return await execute_get_api(workitem, env, workitem_prev_ff, workitem_logs)
            case 'PUT':
                workitem_log = {
                    "log_type" : "INFO",
                    "message" : "Executing " + http_method + " API for workitem_id : " + workitem['workitem_id'],
                    "payload" : workitem_request_params['api_endpoint'],
                    "timestamp" : datetime.utcnow()
                } 
                workitem_logs.append(workitem_log)
                return await execute_put_api(workitem, env, workitem_prev_ff, workitem_logs)
            case 'DELETE':
                workitem_log = {
                    "log_type" : "INFO",
                    "message" : "Executing " + http_method + " API for workitem_id : " + workitem['workitem_id'],
                    "payload" : workitem_request_params['api_endpoint'],
                    "timestamp" : datetime.utcnow()
                } 
                workitem_logs.append(workitem_log)
                return await execute_delete_api(workitem, env, workitem_prev_ff, workitem_logs)
            case _:
                workitem_log = {
                    "log_type" : "ERROR",
                    "message" : "Invalid HTTP Method : " + http_method,
                    "timestamp" : datetime.utcnow()
                } 
                workitem_logs.append(workitem_log)
                return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}
    except Exception as e:
        workitem_log = {
            "log_type" : "ERROR", 
            "message" : "Exception while Executing REST_API for workitem_id :" + workitem['workitem_id'] + " | " + str(e),
            "timestamp" : datetime.utcnow()
        } 
        workitem_logs.append(workitem_log)
        return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}



async def execute_get_api(workitem, env, workitem_prev_ff, workitem_logs):
    try:
        workitem = await rqt_util_service.replace_placeholders(workitem, env, workitem_prev_ff,workitem_logs)
        
        workitem_request_params = workitem['workitem_request_params']
        
        base_url = workitem_request_params['base_url']
        api_endpoint = workitem_request_params['api_endpoint']
        api_url = base_url + api_endpoint

        http_headers = workitem_request_params['http_headers']
    
        response = httpx.get(api_url, headers = http_headers)
        
        if response.content:
            response.raise_for_status()
            response_data = response.json()
            workitem_response_body = response_data
        else :
            workitem_response_body = {}
        
        workitem_log = {
            "log_type" : "INFO",
            "message" : "Successfully Executed GET API for workitem_id : " + workitem['workitem_id'] + " with Response",
            "payload" : workitem_response_body,
            "timestamp" : datetime.utcnow()
        } 
        workitem_logs.append(workitem_log)

        await rqt_util_service.generate_next_feed_forward(workitem, env, workitem_response_body, workitem_logs)
        return await rqt_util_service.validate_expected_and_actual_response(workitem, env, workitem_response_body, workitem_logs)  
    
    except httpx.HTTPStatusError as exc:
        print(f"HTTP error occurred: {exc.response.status_code} - {exc.response.text}")
        workitem_log = {
            "log_type" : "ERROR",
            "message" : "HTTP error occurred while executing GET API | " + str(exc.response.status_code) + " - " + str(exc.response.text),
            "payload" : workitem_response_body,
            "timestamp" : datetime.utcnow()
        } 
        workitem_logs.append(workitem_log)
        return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}
    
    except Exception as exc:
        print(f"An error occurred: {exc}")
        workitem_log = {
            "log_type" : "ERROR",
            "message" : "Exception while executing GET API | " + str(exc),
            "payload" : workitem_response_body,
            "timestamp" : datetime.utcnow()
        } 
        workitem_logs.append(workitem_log)
        return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}



async def execute_post_api(workitem, env, workitem_prev_ff, workitem_logs):
    try:
        workitem = await rqt_util_service.replace_placeholders(workitem, env, workitem_prev_ff,workitem_logs)
        
        workitem_request_params = workitem['workitem_request_params']
        
        base_url = workitem_request_params['base_url']
        api_endpoint = workitem_request_params['api_endpoint']
        api_url = base_url + api_endpoint

        http_headers = workitem_request_params['http_headers']
        request_body = workitem_request_params['request_body']
    
        response = httpx.post(api_url, headers = http_headers, json = request_body)
        
        if response.content:
            response.raise_for_status()
            response_data = response.json()
            workitem_response_body = response_data
        else :
            workitem_response_body = {}
            print("Void Response or No Response")


        workitem_log = {
            "log_type" : "INFO",
            "message" : "Successfully Executed POST API for workitem_id : " + workitem['workitem_id'] + " with Response",
            "payload" : workitem_response_body,
            "timestamp" : datetime.utcnow()
        } 
        workitem_logs.append(workitem_log)
        
        await rqt_util_service.generate_next_feed_forward(workitem, env, workitem_response_body, workitem_logs)
        return await rqt_util_service.validate_expected_and_actual_response(workitem, env, workitem_response_body, workitem_logs)  
    except httpx.HTTPStatusError as exc:
        print(f"HTTP error occurred: {exc.response.status_code} - {exc.response.text}")
        workitem_log = {
            "log_type" : "ERROR",
            "message" : "HTTP error occurred while executing POST API | " + str(exc.response.status_code) + " - " + str(exc.response.text),
            "payload" : workitem_response_body,
            "timestamp" : datetime.utcnow()
        } 
        workitem_logs.append(workitem_log)
        
        return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}
    except Exception as exc:
        print(f"An error occurred: {exc}")
        workitem_log = {
            "log_type" : "ERROR",
            "message" : "Exception while executing POST API | " + str(exc),
            "payload" : workitem_response_body,
            "timestamp" : datetime.utcnow()
        } 
        workitem_logs.append(workitem_log)
        return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}



async def execute_put_api(workitem, env, workitem_prev_ff, workitem_logs):
    try:
        workitem = await rqt_util_service.replace_placeholders(workitem, env, workitem_prev_ff,workitem_logs)
        
        workitem_request_params = workitem['workitem_request_params']
        
        base_url = workitem_request_params['base_url']
        api_endpoint = workitem_request_params['api_endpoint']
        api_url = base_url + api_endpoint

        http_headers = workitem_request_params['http_headers']
        request_body = workitem_request_params['request_body']
    
        response = httpx.put(api_url, headers = http_headers, json = request_body)
        
        if response.content:
            response.raise_for_status()
            response_data = response.json()
            workitem_response_body = response_data
        else :
            workitem_response_body = {}
            print("Void Response or No Response")

        
        workitem_log = {
            "log_type" : "INFO",
            "message" : "Successfully Executed PUT API for workitem_id : " + workitem['workitem_id'] + " with Response",
            "payload" : workitem_response_body,
            "timestamp" : datetime.utcnow()
        } 
        workitem_logs.append(workitem_log)

        await rqt_util_service.generate_next_feed_forward(workitem, env, workitem_response_body, workitem_logs)
        return await rqt_util_service.validate_expected_and_actual_response(workitem, env, workitem_response_body, workitem_logs)  
    except httpx.HTTPStatusError as exc:
        print(f"HTTP error occurred: {exc.response.status_code} - {exc.response.text}")
        workitem_log = {
            "log_type" : "ERROR",
            "message" : "HTTP error occurred while executing PUT API | " + str(exc.response.status_code) + " - " + str(exc.response.text),
            "payload" : workitem_response_body,
            "timestamp" : datetime.utcnow()
        } 
        workitem_logs.append(workitem_log)
        return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}
    except Exception as exc:
        print(f"An error occurred: {exc}")
       
        workitem_log = {
            "log_type" : "ERROR",
            "message" : "Exception while executing PUT API | " + str(exc),
            "payload" : workitem_response_body,
            "timestamp" : datetime.utcnow()
        } 
        workitem_logs.append(workitem_log)
        return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}


async def execute_delete_api(workitem, env, workitem_prev_ff, workitem_logs):
    try:
        workitem = await rqt_util_service.replace_placeholders(workitem, env, workitem_prev_ff,workitem_logs)
        
        workitem_request_params = workitem['workitem_request_params']
        
        base_url = workitem_request_params['base_url']
        api_endpoint = workitem_request_params['api_endpoint']
        api_url = base_url + api_endpoint

        http_headers = workitem_request_params['http_headers']
        request_body = workitem_request_params['request_body']
    
        response = httpx.delete(api_url, headers = http_headers, json = request_body)
        
        if response.content:
            response.raise_for_status()
            response_data = response.json()
            workitem_response_body = response_data
        else :
            workitem_response_body = {}
            print("Void Response or No Response")

        workitem_log = {
            "log_type" : "INFO",
            "message" : "Successfully Executed DELETE API for workitem_id : " + workitem['workitem_id'] + " with Response",
            "payload" : workitem_response_body,
            "timestamp" : datetime.utcnow()
        } 
        workitem_logs.append(workitem_log)

        await rqt_util_service.generate_next_feed_forward(workitem, env, workitem_response_body, workitem_logs)
        return await rqt_util_service.validate_expected_and_actual_response(workitem, env, workitem_response_body, workitem_logs)  
    except httpx.HTTPStatusError as exc:
        print(f"HTTP error occurred: {exc.response.status_code} - {exc.response.text}")
        workitem_log = {
            "log_type" : "ERROR",
            "message" : "HTTP error occurred while executing DELETE API | " + str(exc.response.status_code) + " - " + str(exc.response.text),
            "payload" : workitem_response_body,
            "timestamp" : datetime.utcnow()
        } 
        workitem_logs.append(workitem_log)
        return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}
    except Exception as exc:
        print(f"An error occurred: {exc}")
                
        workitem_log = {
            "log_type" : "ERROR",
            "message" : "Exception while executing DELETE API | " + str(exc),
            "payload" : workitem_response_body,
            "timestamp" : datetime.utcnow()
        } 
        workitem_logs.append(workitem_log)

        return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}
