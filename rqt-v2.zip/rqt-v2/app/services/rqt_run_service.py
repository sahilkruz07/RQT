from app.models.requests.rqt_bff_controller_requests import *
from app.services import rqt_bff_service,rqt_sql_service,rqt_rest_service,rqt_mongo_service,rqt_util_service
from app.models.requests.rqt_run_controller_requests import *
from app.utils.generators import datetime_generator,id_generator
from app.repositories import rqt_counter_master_repository, rqt_run_testcase_audit_repository
from app.utils.constants import rqt_constants
from datetime import datetime
from app.utils.serializers import run_testcase_response_serializer
from app.utils.mappers import mapper
from app.utils.enums import workitem_status_enum,testcase_status_enum

async def run_workitem(request : RunWorkitemRequest):

    env = request.env
    workitem_id = request.workitem_id
    workitem_prev_ff = request.workitem_prev_ff
    
    workitem_logs = []
    try :
        if env not in rqt_constants.ALLOWED_ENV_LIST:
            workitem_log = {
                "log_type" : "ERROR",
                "message" : "Environment : "+env+" not present in ALLOWED_ENV_LIST",
                "timestamp" : datetime.utcnow()
            } 
            workitem_logs.append(workitem_log)
            return {"workitem_id" : workitem_id, "env" :  env, "workitem" : {}, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}
        

        workitem = await rqt_bff_service.fetch_workitem(workitem_id)
        
        if workitem is None:
            workitem_log = {
                "log_type" : "ERROR",
                "message" : "Work-item not present or deleted for workitem_id : " + workitem_id,
                "timestamp" : datetime.utcnow()
            } 
            workitem_logs.append(workitem_log)
            return {"workitem_id" : workitem_id, "env" :  env, "workitem" : {}, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}

        workitem_type = workitem['workitem_type']
        match workitem_type:
            
            case 'SQL_QUERY':
                workitem_log = {
                    "log_type" : "INFO",
                    "message" : "Executing work-item of type : "+workitem_type+" for workitem_id : " + workitem_id,
                    "payload" : workitem_type,
                    "timestamp" : datetime.utcnow()
                } 
                workitem_logs.append(workitem_log)
                run_workitem_response = await rqt_sql_service.execute_sql_query(workitem, env, workitem_prev_ff, workitem_logs)
                return run_workitem_response
            
            
            case 'MONGO_QUERY':
                workitem_log = {
                    "log_type" : "INFO",
                    "message" : "Executing work-item of type : "+workitem_type+" for workitem_id : " + workitem_id,
                    "timestamp" : datetime.utcnow()
                } 
                workitem_logs.append(workitem_log)
                run_workitem_response = await rqt_mongo_service.execute_mongo_query(workitem, env, workitem_prev_ff, workitem_logs)
                return run_workitem_response
            
            
            case 'REST_API':
                workitem_log = {
                    "log_type" : "INFO",
                    "message" : "Executing work-item of type : "+workitem_type+" for workitem_id : " + workitem_id,
                    "timestamp" : datetime.utcnow()
                } 
                workitem_logs.append(workitem_log)
                run_workitem_response = await rqt_rest_service.execute_rest_api(workitem, env, workitem_prev_ff, workitem_logs)
                return run_workitem_response
    
    except Exception as e:
        
        workitem_log = {
            "log_type" : "ERROR",
            "message" : "Exception while executing work-item for workitem_id : "+workitem_id+" | " + str(e),
            "timestamp" : datetime.utcnow()
        } 
        workitem_logs.append(workitem_log)

        return {"workitem_id" : workitem_id, "env" :  env, "workitem" : {}, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}

    workitem_log = {
        "log_type" : "ERROR",
        "message" : "Invalid workitem_type : " + workitem_type,
        "timestamp" : datetime.utcnow()
    } 
    workitem_logs.append(workitem_log)
    
    return {"workitem_id" : workitem_id, "env" :  env, "workitem" : {}, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}


async def run_testcase(request : RunTestcaseRequest):
    run_testcase_start_date = datetime.utcnow()
    testcase_id = request.testcase_id
    env = request.env
    testcase_executor_context = request.testcase_executor_context
    
    testcase = await rqt_bff_service.fetch_testcase(testcase_id)
    if testcase is None:
        return None
    testcase_workitem_list = testcase['testcase_workitem_list']

    workitem_prev_ff = {}
    run_workitem_status_list = []
    
    all_workitems_passed = True
    run_testcase_status = testcase_status_enum.PASSED

    for workitem_id in testcase_workitem_list:
        if all_workitems_passed:
            run_workitem_request = {
                "env" : env,
                "workitem_id" : workitem_id,
                "workitem_prev_ff" : workitem_prev_ff,
                "workitem_executor_context" : testcase_executor_context
            }
            run_workitem_request_body = RunWorkitemRequest(**run_workitem_request)
            run_workitem_response = await run_workitem(run_workitem_request_body)
            run_workitem_status = run_workitem_response['workitem_status']
            run_workitem_logs = run_workitem_response['workitem_logs']
            workitem_title = run_workitem_response['workitem']['workitem_title']
            if run_workitem_status == workitem_status_enum.FAILED:
                all_workitems_passed = False
                run_testcase_status = testcase_status_enum.FAILED
            else :
                workitem_prev_ff = run_workitem_response['workitem']['workitem_feed_forward']
        else :
            run_workitem_status = workitem_status_enum.PENDING
        
        run_workitem_status_list.append({"workitem_id" : workitem_id, "workitem_title" :workitem_title ,"workitem_status" : run_workitem_status , "workitem_logs" :run_workitem_logs})

    run_testcase_counter = await rqt_counter_master_repository.find_counter_by_counter_name(rqt_constants.RUN_TESTCASE_COUNTER)
    counter_value = run_testcase_counter['counter_value']
    run_testcase_id = id_generator.run_testcase_id_generater(counter_value)
    
    run_testcase_end_date = datetime.utcnow()
    run_testcase_duration = datetime_generator.find_duration_between(run_testcase_start_date,run_testcase_end_date)
    
    run_testcase_audit_log = {
        "run_testcase_id" : run_testcase_id,
        "testcase_id" : testcase_id,
        "run_testcase_env" : env,
        "run_testcase_status" : run_testcase_status,
        "run_workitem_status_list" : run_workitem_status_list,
        "run_testcase_start_date" : run_testcase_start_date,
        "run_testcase_end_date" : run_testcase_end_date,
        "run_testcase_duration" : run_testcase_duration,
        "run_testcase_executor_context" : testcase_executor_context
    }

    await rqt_run_testcase_audit_repository.insert_to_db(run_testcase_audit_log)
    await rqt_counter_master_repository.update_counter(rqt_constants.RUN_TESTCASE_COUNTER,counter_value)

    serialized_run_testcase_audit_log = run_testcase_response_serializer.serialize_run_testcase_audit_log(run_testcase_audit_log)

    required_fields = ['run_testcase_id','testcase_id','run_testcase_env','run_testcase_status','run_workitem_status_list','run_testcase_start_date','run_testcase_end_date','run_testcase_duration','run_testcase_executor_context']    
    return mapper.map_required_fields(required_fields,serialized_run_testcase_audit_log)


async def run_testcases_bulk(request : RunTestcaseBulkRequest):
    testcase_id_list = request.testcase_id_list
    env = request.env
    run_testcase_executor_context = request.run_testcase_executor_context

    run_testcases_bulk_response = {}
    for testcase_id in testcase_id_list:
        run_testcase_request = {
            "testcase_id" : testcase_id,
            "env" : env,
            "testcase_executor_context" : run_testcase_executor_context
        }
        run_testcase_request_body = RunTestcaseRequest(**run_testcase_request)
        run_testcase_response = await run_testcase(run_testcase_request_body)
        run_testcases_bulk_response[testcase_id] = run_testcase_response
    
    return run_testcases_bulk_response