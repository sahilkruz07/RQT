from http.client import HTTPException
from app.repositories import rqt_env_config_repository
from app.utils.constants import rqt_constants
import re
import httpx
from app.utils.enums import workitem_status_enum
from datetime import datetime


async def replace_placeholders(workitem, env, workitem_prev_ff,workitem_logs):
    try:
        await iterate_nested_dict_and_replace(workitem, env, 'WORKITEM_PREV_FF', workitem_prev_ff)
    except Exception as e:
        workitem_log = {
            "log_type" : "ERROR",
            "message" : "Replacing Placeholders failed for workitem_id : " + workitem['workitem_id'] + " | " + str(e),
            "timestamp" : datetime.utcnow()
        } 
        workitem_logs.append(workitem_log)

    workitem_log = {
        "log_type" : "INFO",
        "message" : "Work-item after replacing placeholders for workitem_id : " + workitem['workitem_id'],
        "payload" : workitem,
        "timestamp" : datetime.utcnow()
    } 
    workitem_logs.append(workitem_log)

    return workitem

async def iterate_nested_dict_and_replace(d, env, dict_name, dict_map):
    for key in d:
        value = d[key]
        if isinstance(value, dict):
            await iterate_nested_dict_and_replace(value, env, dict_name ,dict_map)
        else:
            if isinstance(value, str):
                
                if dict_name == 'WORKITEM_PREV_FF':
                    if value.startswith(rqt_constants.PREV_FF_PREFIX):
                        config_key = value[len(rqt_constants.PREV_FF_PREFIX):]
                        new_value = dict_map[config_key]
                        d[key] = new_value
                    elif rqt_constants.PREV_FF_PREFIX in value:
                        pattern = rqt_constants.PREV_FF_PATTERN
                        new_value = re.sub(pattern, lambda match: replacer(match, dict_map), value)
                        d[key] = new_value
                
                elif dict_name == 'WORKITEM_REQ_FF':
                    if value.startswith(rqt_constants.REQ_FF_PREFIX):
                        config_key = value[len(rqt_constants.REQ_FF_PREFIX):]
                        new_value = dict_map[config_key]
                        d[key] = new_value
                    elif rqt_constants.REQ_FF_PREFIX in value:
                        pattern = rqt_constants.REQ_FF_PATTERN
                        new_value = re.sub(pattern, lambda match: replacer(match, dict_map), value)
                        d[key] = new_value
                
                elif dict_name == 'WORKITEM_RESP_FF':
                    if value.startswith(rqt_constants.RESP_FF_PREFIX):
                        config_key = value[len(rqt_constants.RESP_FF_PREFIX):]
                        new_value = dict_map[config_key]
                        d[key] = new_value
                    elif rqt_constants.RESP_FF_PREFIX in value:
                        pattern = rqt_constants.RESP_FF_PATTERN
                        new_value = re.sub(pattern, lambda match: replacer(match, dict_map), value)
                        d[key] = new_value

                if value.startswith(rqt_constants.ENV_PREFIX):
                    config_key = value[len(rqt_constants.ENV_PREFIX):]
                    new_value = await get_value_from_env_config(config_key,env)
                    d[key] = new_value

                if value.startswith(rqt_constants.UTILS_PREFIX):
                    utils_name = value[len(rqt_constants.UTILS_PREFIX):]
                    new_value = await get_value_for_utility(utils_name,env)
                    d[key] = new_value


def replacer(match,d):
    key = match.group(1)
    if key in d:
        return str(d[key])
    else:
        raise KeyError(f"Key '{key}' not found ")


async def get_value_from_env_config(config_key ,env):
    env_config = await rqt_env_config_repository.find_env_config_by_config_key_and_env(config_key,env)
    if env_config is None:
        return None
    env_config_value = env_config['config_value']
    return env_config_value
    

async def get_value_for_utility(utils_name, env):
    match utils_name:
        case 'BEARER_TOKEN':
            return await generate_bearer_token(env)
        case 'JSESSION_ID_ANY':
            return await generate_jsession_id(utils_name,env)
        

async def generate_next_feed_forward(workitem, env, workitem_response_body, workitem_logs):
    workitem_request_body = {}
    if 'request_body' in workitem['workitem_request_params']:
        workitem_request_body = workitem['workitem_request_params']['request_body']

    await iterate_nested_dict_and_replace(workitem, env, 'WORKITEM_REQ_FF', workitem_request_body)
    await iterate_nested_dict_and_replace(workitem, env, 'WORKITEM_RESP_FF', workitem_response_body)


async def validate_expected_and_actual_response(workitem, env, workitem_response_body, workitem_logs):
    actual_response = workitem_response_body
    expected_response = workitem['workitem_expected_resp']
    
    validations_map = validate_response(actual_response,expected_response)
    
    workitem_log = {
        "log_type" : "INFO",
        "message" : "Validations performed over Expected and Actual Response : ",
        "payload" : validations_map,
        "timestamp" : datetime.utcnow()
    } 
    workitem_logs.append(workitem_log)
    
    all_fields_validated = True
    for key in validations_map:
        if validations_map[key]['validation_status'] == False:
            all_fields_validated = False
            break
    

    
    if all_fields_validated:
        workitem_log = {
            "log_type" : "INFO",
            "message" : "All Validations performed over Expected and Actual Response Passed",
            "payload" : validations_map,
            "timestamp" : datetime.utcnow()
        } 
        workitem_logs.append(workitem_log)
        return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.PASSED, "workitem_logs" : workitem_logs}
    else :
        workitem_log = {
            "log_type" : "ERROR",
            "message" : "Validation failed over Expected and Actual Response",
            "timestamp" : datetime.utcnow()
        } 
        workitem_logs.append(workitem_log)
        return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}


async def generate_jsession_id(utils_name, env):
    match utils_name:
        case 'JSESSION_ID_ANY':
            jsession_id_any_config = await get_value_from_env_config('JSESSION_ID_ANY_CONFIG',env)
            return await generate_jsession_id_for_ops(jsession_id_any_config, env)
        case 'JSESSION_ID_ACCEPTANCE_MANAGER':
            jsession_id_acceptance_manager_config = await get_value_from_env_config('JSESSION_ID_ACCEPTANCE_MANAGER_CONFIG',env)
            return await generate_jsession_id_for_ops(jsession_id_acceptance_manager_config, env)
        case 'JSESSION_ID_LSP_ADMIN':
            jsession_id_lsp_admin_config = await get_value_from_env_config('JSESSION_ID_LSP_ADMIN',env)
            return await generate_jsession_id_for_ops(jsession_id_lsp_admin_config, env)
    return None

async def generate_jsession_id_for_ops(jsession_id_config, env):
    auth_username = jsession_id_config['auth_username']
    auth_password = jsession_id_config['auth_password']

    ops_login_url = await get_value_from_env_config('OPS_LOGIN_URL',env)
    headers = {
        "Content-Type": "application/json",
    }
    
    request_body = {
        "username": auth_username,
        "password": auth_password
    }

    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(ops_login_url, headers=headers, json=request_body)
            response.raise_for_status() 
            response_body = response.json()
            session_id = response_body['sessionId']
            jsession_id = "JSESSIONID=" + session_id
            return jsession_id
    except Exception as err:      
        print(f"Request to {ops_login_url} failed : {err}")
        return None


async def generate_bearer_token(env):
    bearer_token_config = await get_value_from_env_config('BEARER_TOKEN_CONFIG',env)
    bearer_token_url = bearer_token_config['bearer_token_url']
    bearer_client_id = bearer_token_config['bearer_client_id']
    bearer_client_secret = bearer_token_config['bearer_client_secret']
    
    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
    }

    data = {
        "client_id": bearer_client_id,
        "client_secret": bearer_client_secret,
        "grant_type": "client_credentials"
    }
    
    await iterate_nested_dict_and_replace(data, env, '', {})

    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(bearer_token_url, headers=headers, data=data)
            response.raise_for_status() 
            response_body = response.json()
            access_token = response_body['access_token']
            bearer_token = "Bearer " + access_token
            return bearer_token
    except Exception as err:      
        print(f"Request to {bearer_token_url} failed : {err}")
        return None
    

def validate_response(actual, expected):
    validations_map = {}

    def compare_dicts(actual_dict, expected_dict, path=""):
        for key, expected_value in expected_dict.items():
            current_path = f"{path}.{key}" if path else key
            if key not in actual_dict:
                validations_map[current_path] = {
                    "actual_value" : "_#_KEY_NOT_FOUND_#_",
                    "expected_value" : expected_value,
                    "validation_status" : False
                }
            elif isinstance(expected_value, dict) and isinstance(actual_dict[key], dict):
                compare_dicts(actual_dict[key], expected_value, current_path)
            else:
                validations_map[current_path] = {
                    "actual_value" : actual_dict[key],
                    "expected_value" : expected_value,
                    "validation_status" : actual_dict[key] == expected_value
                }
    
    compare_dicts(actual, expected)
    return validations_map