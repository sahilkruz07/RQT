from app.utils.serializers import testcase_serializer,workitem_serializer,testsuite_serializer
from app.repositories import rqt_env_config_logs_repository, rqt_testcase_master_logs_repository, rqt_testcase_master_repository, rqt_workitem_master_logs_repository,rqt_workitem_master_repository,rqt_counter_master_repository,rqt_env_config_repository,rqt_testsuite_master_repository,rqt_testsuite_master_logs_repository,rqt_run_testcase_audit_repository
from app.models.requests.rqt_bff_controller_requests import *
from app.utils.constants import rqt_constants
from app.utils.generators import id_generator
from datetime import datetime
from app.utils.mappers import mapper

async def fetch_testcase(testcase_id : str):
    testcase = await rqt_testcase_master_repository.find_test_case_by_testcase_id_is_deleted(testcase_id,False)
    if testcase is None :
        return None
    serialised_testcase =  testcase_serializer.serialize_testcase(testcase)
    required_fields = ['testcase_id','testcase_title','testcase_subtitle','testcase_tag','testcase_workitem_list','testcase_is_deleted','testcase_created_date','testcase_updated_date','testcase_modified_context']
    return mapper.map_required_fields(required_fields,serialised_testcase)


async def fetch_testcases_bulk(request : FetchBulkTestcaseRequest):
    testcase_id_list = request.testcase_id_list
    testcase_list = []
    for testcase_id in testcase_id_list:
        testcase = await fetch_testcase(testcase_id)
        if testcase is not None:
            testcase_list.append(testcase)    
    return testcase_list


async def add_new_testcase(request : AddTestcaseRequest):
    testcase_counter = await rqt_counter_master_repository.find_counter_by_counter_name(rqt_constants.TESTCASE_COUNTER)
    counter_value = testcase_counter['counter_value']
    testcase_id = id_generator.testcase_id_generater(counter_value)
    new_testcase = {
        "testcase_id" : testcase_id,
        "testcase_title" : request.testcase_title,
        "testcase_subtitle" : request.testcase_subtitle,
        "testcase_tag" : request.testcase_tag,
        "testcase_workitem_list" : request.testcase_workitem_list,
        "testcase_is_deleted" : False,
        "testcase_modified_context" : request.testcase_modified_context,
        "testcase_created_date" : datetime.utcnow(),
        "testcase_updated_date" : datetime.utcnow(),
    }
    await rqt_testcase_master_repository.insert_to_db(new_testcase)
    await rqt_counter_master_repository.update_counter(rqt_constants.TESTCASE_COUNTER,counter_value)
    await rqt_testcase_master_logs_repository.insert_to_db(new_testcase)
    
    return {"message" : "Added new Testcase for "+ testcase_id}


async def update_testcase(request : UpdateTestcaseRequest):
    testcase_id = request.testcase_id
    testcase = await fetch_testcase(testcase_id)
    if testcase is None :
        return {"message" : "Testcase not found or delete for "+ testcase_id}
    
    request_dict = dict(request)

    fields_to_update = ['testcase_title','testcase_subtitle','testcase_tag','testcase_workitem_list','testcase_is_deleted','testcase_modified_context']
    updated_testcase = {}
    testcase_audit_log = testcase

    for field in request_dict:
        if field in fields_to_update and request_dict[field] is not None:
            updated_testcase[field] = request_dict[field] 
            testcase_audit_log[field] = request_dict[field]
    updated_testcase['testcase_updated_date'] = datetime.utcnow() 
    testcase_audit_log['testcase_updated_date'] = datetime.utcnow() 

    await rqt_testcase_master_repository.update_to_db(testcase_id,updated_testcase)
    await rqt_testcase_master_logs_repository.insert_to_db(testcase_audit_log)

    return {"message" : "Updated Testcase for "+ testcase_id}


async def fetch_workitem(workitem_id : str):
    workitem = await rqt_workitem_master_repository.find_workitem_by_workitem_id_is_deleted(workitem_id,False)
    if workitem is None:
        return None
    serialised_workitem = workitem_serializer.serialize_workitem(workitem)
    required_fields = ['workitem_id','workitem_title','workitem_type','workitem_request_params','workitem_expected_resp','workitem_feed_forward','workitem_is_deleted','workitem_created_date','workitem_updated_date','workitem_modified_context']
    return mapper.map_required_fields(required_fields,serialised_workitem)


async def fetch_workitems_bulk(request : FetchBulkWorkitemRequest):
    workitem_id_list = request.workitem_id_list
    workitem_list = []
    for workitem_id in workitem_id_list:
        workitem = await fetch_workitem(workitem_id)
        if workitem is not None:
            workitem_list.append(workitem)    
    return workitem_list


async def add_new_workitem(request : AddWorkitemRequest):
    workitem_counter = await rqt_counter_master_repository.find_counter_by_counter_name(rqt_constants.WORKITEM_COUNTER)
    counter_value = workitem_counter['counter_value']
    workitem_id = id_generator.workitem_id_generater(counter_value)
    new_workitem = {
        "workitem_id" : workitem_id,
        "workitem_title" : request.workitem_title,
        "workitem_type" : request.workitem_type,
        "workitem_request_params" : request.workitem_request_params,
        "workitem_expected_resp" : request.workitem_expected_resp,
        "workitem_feed_forward" : request.workitem_feed_forward,
        "workitem_is_deleted" : False,
        "workitem_modified_context" : request.workitem_modified_context,
        "workitem_created_date" : datetime.utcnow(),
        "workitem_updated_date" : datetime.utcnow()
    }

    await rqt_workitem_master_repository.insert_to_db(new_workitem)
    await rqt_counter_master_repository.update_counter(rqt_constants.WORKITEM_COUNTER,counter_value)
    await rqt_workitem_master_logs_repository.insert_to_db(new_workitem)

    return {"message" : "Added new Work-item for "+ workitem_id}


async def update_workitem(request : UpdateWorkitemRequest):
    workitem_id = request.workitem_id
    workitem = await fetch_workitem(workitem_id)
    if workitem is None :
        return {"message" : "Work-item not found or deleted for "+ workitem}
    
    request_dict = dict(request)
    fields_to_update = ['workitem_title','workitem_type','workitem_request_params','workitem_expected_resp','workitem_feed_forward','workitem_is_deleted','workitem_modified_context']
    updated_workitem = {}
    workitem_audit_log = workitem
    
    for field in request_dict:
        if field in fields_to_update and request_dict[field] is not None:
            updated_workitem[field] = request_dict[field] 
            workitem_audit_log[field] = request_dict[field]
    updated_workitem['workitem_updated_date'] = datetime.utcnow() 
    workitem_audit_log['workitem_updated_date'] = datetime.utcnow()
    
    await rqt_workitem_master_repository.update_to_db(workitem_id,updated_workitem)
    await rqt_workitem_master_logs_repository.insert_to_db(workitem_audit_log)

    return {"message" : "Updated Work-item for "+ workitem_id}


async def fetch_env_config(env : str ,config_key : str):
    env_config = rqt_env_config_repository.find_env_config_by_config_key_and_env(config_key,env)
    if env_config is None:
        return None
    return env_config


async def add_new_env_config(request : AddEnvConfigRequest):
    env = request.env
    config_key = request.config_key

    env_config = await fetch_env_config(config_key, env)
    if env_config is not None:
        return {"message" : "Config already present for config_key : " + config_key + " in env : " + env }
    
    new_env_config = {
        "config_key" : config_key,
        "env" : env,
        "config_value" : request.config_value,
        "config_created_date" : datetime.utcnow(),
        "config_updated_date" : datetime.utcnow(),
        "config_modified_context" : request.config_modified_context
    }
    
    await rqt_env_config_repository.insert_to_db(new_env_config)
    await rqt_env_config_logs_repository.insert_to_db(new_env_config)

    return {"message" : "Added new Env Config for config_key : " + config_key + " in env : " + env }


async def update_env_config(request : UpdateEnvConfigRequest):
    env = request.env
    config_key = request.config_key

    env_config = fetch_env_config(config_key, env)
    if env_config is None:
        return {"message" : "Config not found for config_key : " + config_key + " in env : " + env }
    
    updated_env_config = env_config
    request_dict = dict(request)
    fields_to_update = ['config_value','config_modified_context']
    for field in request_dict:
        if field in fields_to_update:
            updated_env_config[field] = request_dict[field]
    updated_env_config['config_updated_date'] = datetime.utcnow()

    await rqt_env_config_repository.update_to_db(config_key, env, updated_env_config)
    await rqt_env_config_logs_repository.insert_to_db(updated_env_config)

    return {"message" : "Updated Env Config for config_key : " + config_key + " in env : " + env }


async def fetch_testsuite(testsuite_id : str):
    testsuite = await rqt_testsuite_master_repository.find_test_suite_by_testsuite_id_is_deleted(testsuite_id,False)
    if testsuite is None :
        return None
    serialised_testsuite =  testsuite_serializer.serialize_testsuite(testsuite)
    required_fields = ['testsuite_id','testsuite_title','testsuite_subtitle','testsuite_testcase_list','testsuite_is_deleted','testsuite_created_date','testsuite_updated_date','testsuite_modified_context']
    return mapper.map_required_fields(required_fields,serialised_testsuite)


async def add_new_testsuite(request : AddTestsuiteRequest):
    testsuite_counter = await rqt_counter_master_repository.find_counter_by_counter_name(rqt_constants.TESTSUITE_COUNTER)
    counter_value = testsuite_counter['counter_value']
    testsuite_id = id_generator.testsuite_id_generater(counter_value)
    new_testsuite = {
        "testsuite_id" : testsuite_id,
        "testsuite_title" : request.testsuite_title,
        "testsuite_subtitle" : request.testsuite_subtitle,
        "testsuite_workitem_list" : request.testsuite_testcase_list,
        "testsuite_is_deleted" : False,
        "testsuite_modified_context" : request.testsuite_modified_context,
        "testsuite_created_date" : datetime.utcnow(),
        "testsuite_updated_date" : datetime.utcnow(),
    }
    await rqt_testsuite_master_repository.insert_to_db(new_testsuite)
    await rqt_counter_master_repository.update_counter(rqt_constants.TESTSUITE_COUNTER,counter_value)
    await rqt_testsuite_master_logs_repository.insert_to_db(new_testsuite)
    
    return {"message" : "Added new Test-suite for "+ testsuite_id}


async def update_testsuite(request : UpdateTestsuiteRequest):
    testsuite_id = request.testsuite_id
    testsuite = await fetch_testsuite(testsuite_id)
    if testsuite is None :
        return {"message" : "Test-suite not found or deleted for "+ testsuite_id}
    
    request_dict = dict(request)
    fields_to_update = ['testsuite_title','testsuite_subtitle','testsuite_testcase_list','testsuite_is_deleted','testsuite_updated_date','testsuite_modified_context']
    updated_testsuite = {}
    testsuite_audit_log = testsuite
    
    for field in request_dict:
        if field in fields_to_update and request_dict[field] is not None:
            updated_testsuite[field] = request_dict[field] 
            testsuite_audit_log[field] = request_dict[field]
    updated_testsuite['testsuite_updated_date'] = datetime.utcnow() 
    testsuite_audit_log['testsuite_updated_date'] = datetime.utcnow()
    
    await rqt_testsuite_master_repository.update_to_db(testsuite_id,updated_testsuite)
    await rqt_testsuite_master_logs_repository.insert_to_db(testsuite_audit_log)

    return {"message" : "Updated Test-suite for "+ testsuite_id}

async def fetch_workitem_list(pageNo, searchQuery, sortBy, sortByMethod):

    if searchQuery is None:
        page_size = rqt_constants.PAGE_SIZE
        skip = (pageNo - 1) * page_size
        
        if sortBy == 'date':
            column_name = 'workitem_update_date'
        elif sortBy == 'tag':
            column_name = 'workitem_type'
        elif sortBy == 'id':
            column_name = 'workitem_id'

        sort_order = -1
        if sortByMethod == 'ascending':
            sort_order = 1
        elif sortByMethod == 'descending':
            sort_order = -1

        results = await rqt_workitem_master_repository.find_workitem_by_search_params_without_search_query(skip,page_size,column_name,sort_order)
        
        paginated_results = []
        for result in results:
            
            updated_date_utc = str(result['workitem_updated_date'])
            dt = datetime.fromisoformat(updated_date_utc) 
            formatted_date = dt.strftime("%b %d, %Y %H:%M:%S")

            paginated_result = {
                "id" : result['workitem_id'],
                "name" : result['workitem_title'],
                "tag" : result['workitem_type'],
                "date" : formatted_date
            }

            paginated_results.append(paginated_result)

        return paginated_results

    return None

async def fetch_testcase_list(pageNo, searchQuery, sortBy, sortByMethod):

    if searchQuery is None:
        page_size = rqt_constants.PAGE_SIZE
        skip = (pageNo - 1) * page_size
        
        if sortBy == 'date':
            column_name = 'testcase_update_date'
        elif sortBy == 'tag':
            column_name = 'testcase_tag'
        elif sortBy == 'id':
            column_name = 'testcase_id'

        sort_order = -1
        if sortByMethod == 'ascending':
            sort_order = 1
        elif sortByMethod == 'descending':
            sort_order = -1

        results = await rqt_testcase_master_repository.find_testcase_by_search_params_without_search_query(skip,page_size,column_name,sort_order)
        
        paginated_results = []
        for result in results:
            
            updated_date_utc = str(result['testcase_updated_date'])
            dt = datetime.fromisoformat(updated_date_utc) 
            formatted_date = dt.strftime("%b %d, %Y %H:%M:%S")

            paginated_result = {
                "id" : result['testcase_id'],
                "name" : result['testcase_title'],
                "tag" : result['testcase_tag'],
                "date" : formatted_date
            }

            paginated_results.append(paginated_result)

        return paginated_results
    

    
    return None