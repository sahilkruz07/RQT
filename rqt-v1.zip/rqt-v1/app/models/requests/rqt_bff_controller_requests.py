from pydantic import BaseModel
from typing import List,Dict,Any,Optional

class FetchBulkTestcaseRequest(BaseModel):
    testcase_id_list : List[str]

class AddTestcaseRequest(BaseModel):
    testcase_title : str
    testcase_subtitle : str
    testcase_tag : str
    testcase_workitem_list : List[str]
    testcase_modified_context : str

class UpdateTestcaseRequest(BaseModel):
    testcase_id : str
    testcase_title : Optional[str] = None
    testcase_subtitle : Optional[str] = None
    testcase_tag : Optional[str] = None
    testcase_workitem_list : Optional[List[str]] = None
    testcase_is_deleted : Optional[bool] = None
    testcase_modified_context : str

class FetchBulkWorkitemRequest(BaseModel):
    workitem_id_list : List[str]

class AddWorkitemRequest(BaseModel):
    workitem_title : str
    workitem_type : str
    workitem_request_params : Dict[str, Any]
    workitem_expected_resp : Dict[str, Any]
    workitem_feed_forward : Dict[str, Any]
    workitem_modified_context : str

class UpdateWorkitemRequest(BaseModel):
    workitem_id : str
    workitem_title : Optional[str] = None
    workitem_type : Optional[str] = None
    workitem_request_params : Optional[Dict[str, Any]] = None
    workitem_expected_resp : Optional[Dict[str, Any]] = None
    workitem_feed_forward : Optional[Dict[str, Any]] = None
    workitem_is_deleted : Optional[bool] = None
    workitem_modified_context : str

class AddEnvConfigRequest(BaseModel):
    config_key : str
    env : str
    config_value : Any
    config_modified_context : str

class UpdateEnvConfigRequest(BaseModel):
    config_key : str
    env : str
    config_value : Any
    config_modified_context : str


class AddTestsuiteRequest(BaseModel):
    testsuite_title : str
    testsuite_subtitle : str
    testsuite_testcase_list : List[str]
    testsuite_modified_context : str


class UpdateTestsuiteRequest(BaseModel):
    testsuite_id : str
    testsuite_title : Optional[str] = None
    testsuite_subtitle : Optional[str] = None
    testsuite_testcase_list : Optional[List[str]] = None
    testsuite_is_deleted : Optional[bool] = None
    testsuite_modified_context : str
