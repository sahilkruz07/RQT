from datetime import datetime
def find_duration_between(start_date,end_date):

    duration = end_date - start_date
    total_seconds = int(duration.total_seconds())
    
    hours = total_seconds // 3600  
    minutes = (total_seconds % 3600) // 60  
    seconds = total_seconds % 60 

    formatted_duration = f"{hours:02}:{minutes:02}:{seconds:02}"

    return formatted_duration