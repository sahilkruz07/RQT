from app.utils.constants import rqt_constants

def testcase_id_generater(counter_value):
    new_counter_value = str(counter_value + 1)
    max_len = rqt_constants.TESTCASE_ID_MAX_LEN
    prefix = rqt_constants.TESTCASE_ID_PREFIX
    offset = max_len - len(new_counter_value)
    final_counter = prefix + ("0" * offset) + new_counter_value
    return final_counter

def workitem_id_generater(counter_value):
    new_counter_value = str(counter_value + 1)
    max_len = rqt_constants.WORKITEM_ID_MAX_LEN
    prefix = rqt_constants.WORKITEM_ID_PREFIX
    offset = max_len - len(new_counter_value)
    final_counter = prefix + ("0" * offset) + new_counter_value
    return final_counter

def testsuite_id_generater(counter_value):
    new_counter_value = str(counter_value + 1)
    max_len = rqt_constants.TESTSUITE_ID_MAX_LEN
    prefix = rqt_constants.TESTSUITE_ID_PREFIX
    offset = max_len - len(new_counter_value)
    final_counter = prefix + ("0" * offset) + new_counter_value
    return final_counter

def run_testcase_id_generater(counter_value):
    new_counter_value = str(counter_value + 1)
    max_len = rqt_constants.RUN_TESTCASE_ID_MAX_LEN
    prefix = rqt_constants.RUN_TESTCASE_ID_PREFIX
    offset = max_len - len(new_counter_value)
    final_counter = prefix + ("0" * offset) + new_counter_value
    return final_counter