def serialize_run_testcase_audit_log(run_testcase_audit_log: dict) -> dict:
    if run_testcase_audit_log is None:
        return None
    return {**run_testcase_audit_log, "_id": (str(run_testcase_audit_log['_id'])) } if "_id" in run_testcase_audit_log else run_testcase_audit_log
    