def serialize_workitem(workitem: dict) -> dict:
    if workitem is None:
        return None
    return {**workitem, "_id": (str(workitem['_id'])) } if "_id" in workitem else workitem
    

def serialize_workitem_bulk(workitems: list) -> list:
    return [serialize_workitem(wi) for wi in workitems]