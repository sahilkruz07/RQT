from app.services import rqt_util_service
from app.utils.enums import workitem_status_enum
import httpx

async def execute_rest_api(workitem, env, workitem_prev_ff, workitem_logs):
    try :
        workitem_request_params = workitem['workitem_request_params']
        http_method = workitem_request_params['http_method']
        
        match http_method:
            case 'POST':
                return await execute_post_api(workitem, env, workitem_prev_ff, workitem_logs)
            case 'GET':
                return await execute_get_api(workitem, env, workitem_prev_ff, workitem_logs)
            case 'PUT':
                return await execute_put_api(workitem, env, workitem_prev_ff, workitem_logs)
            case 'DELETE':
                return await execute_delete_api(workitem, env, workitem_prev_ff, workitem_logs)
            case _:
                return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}
    except Exception as e:
        return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}



async def execute_get_api(workitem, env, workitem_prev_ff, workitem_logs):
    try:
        workitem = await rqt_util_service.replace_placeholders(workitem, env, workitem_prev_ff)
        
        workitem_request_params = workitem['workitem_request_params']
        
        base_url = workitem_request_params['base_url']
        api_endpoint = workitem_request_params['api_endpoint']
        api_url = base_url + api_endpoint

        http_headers = workitem_request_params['http_headers']
    
        response = httpx.get(api_url, headers = http_headers)
        
        if response.content:
            response.raise_for_status()
            response_data = response.json()
            workitem_response_body = response_data
        else :
            workitem_response_body = {}
            print("Void Response or No Response")

        await rqt_util_service.generate_next_feed_forward(workitem, env, workitem_response_body, workitem_logs)
        return await rqt_util_service.validate_expected_and_actual_response(workitem, env, workitem_response_body, workitem_logs)  
    except httpx.HTTPStatusError as exc:
        print(f"HTTP error occurred: {exc.response.status_code} - {exc.response.text}")
        return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}
    except Exception as exc:
        print(f"An error occurred: {exc}")
        return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}



async def execute_post_api(workitem, env, workitem_prev_ff, workitem_logs):
    try:
        workitem = await rqt_util_service.replace_placeholders(workitem, env, workitem_prev_ff)
        
        workitem_request_params = workitem['workitem_request_params']
        
        base_url = workitem_request_params['base_url']
        api_endpoint = workitem_request_params['api_endpoint']
        api_url = base_url + api_endpoint

        http_headers = workitem_request_params['http_headers']
        request_body = workitem_request_params['request_body']
    
        response = httpx.post(api_url, headers = http_headers, json = request_body)
        
        if response.content:
            response.raise_for_status()
            response_data = response.json()
            workitem_response_body = response_data
        else :
            workitem_response_body = {}
            print("Void Response or No Response")

        print("------------------------------------------------------")
        print("Here 2 :")
        print(workitem_response_body)
        print("------------------------------------------------------")

        await rqt_util_service.generate_next_feed_forward(workitem, env, workitem_response_body, workitem_logs)
        return await rqt_util_service.validate_expected_and_actual_response(workitem, env, workitem_response_body, workitem_logs)  
    except httpx.HTTPStatusError as exc:
        print(f"HTTP error occurred: {exc.response.status_code} - {exc.response.text}")
        return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}
    except Exception as exc:
        print(f"An error occurred: {exc}")
        return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}



async def execute_put_api(workitem, env, workitem_prev_ff, workitem_logs):
    try:
        workitem = await rqt_util_service.replace_placeholders(workitem, env, workitem_prev_ff)
        
        workitem_request_params = workitem['workitem_request_params']
        
        base_url = workitem_request_params['base_url']
        api_endpoint = workitem_request_params['api_endpoint']
        api_url = base_url + api_endpoint

        http_headers = workitem_request_params['http_headers']
        request_body = workitem_request_params['request_body']
    
        response = httpx.put(api_url, headers = http_headers, json = request_body)
        
        if response.content:
            response.raise_for_status()
            response_data = response.json()
            workitem_response_body = response_data
        else :
            workitem_response_body = {}
            print("Void Response or No Response")

        await rqt_util_service.generate_next_feed_forward(workitem, env, workitem_response_body, workitem_logs)
        return await rqt_util_service.validate_expected_and_actual_response(workitem, env, workitem_response_body, workitem_logs)  
    except httpx.HTTPStatusError as exc:
        print(f"HTTP error occurred: {exc.response.status_code} - {exc.response.text}")
        return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}
    except Exception as exc:
        print(f"An error occurred: {exc}")
        return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}


async def execute_delete_api(workitem, env, workitem_prev_ff, workitem_logs):
    try:
        workitem = await rqt_util_service.replace_placeholders(workitem, env, workitem_prev_ff)
        
        workitem_request_params = workitem['workitem_request_params']
        
        base_url = workitem_request_params['base_url']
        api_endpoint = workitem_request_params['api_endpoint']
        api_url = base_url + api_endpoint

        http_headers = workitem_request_params['http_headers']
        request_body = workitem_request_params['request_body']
    
        response = httpx.delete(api_url, headers = http_headers, json = request_body)
        
        if response.content:
            response.raise_for_status()
            response_data = response.json()
            workitem_response_body = response_data
        else :
            workitem_response_body = {}
            print("Void Response or No Response")

        await rqt_util_service.generate_next_feed_forward(workitem, env, workitem_response_body, workitem_logs)
        return await rqt_util_service.validate_expected_and_actual_response(workitem, env, workitem_response_body, workitem_logs)  
    except httpx.HTTPStatusError as exc:
        print(f"HTTP error occurred: {exc.response.status_code} - {exc.response.text}")
        return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}
    except Exception as exc:
        print(f"An error occurred: {exc}")
        return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}
