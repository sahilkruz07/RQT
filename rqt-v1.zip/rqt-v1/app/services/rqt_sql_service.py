from app.services import rqt_util_service
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from sqlalchemy import text
from app.utils.enums import workitem_status_enum


async def execute_sql_query(workitem, env, workitem_prev_ff, workitem_logs):
    try :
        workitem = await rqt_util_service.replace_placeholders(workitem, env, workitem_prev_ff)
        workitem_request_params = workitem['workitem_request_params']
        database_name = workitem_request_params['database_name']
        db_session_maker = await get_sql_db_connection(database_name, env)

        query_type = workitem_request_params['query_type']
        match query_type:
            case 'SELECT':
                return await execute_sql_select_query(db_session_maker, workitem, env, workitem_logs)
            case 'INSERT':
                return await execute_sql_insert_query(db_session_maker, workitem, env, workitem_logs)
            case 'UPDATE':
                return await execute_sql_update_query(db_session_maker, workitem, env, workitem_logs)
            case 'DELETE':
                return await execute_sql_delete_query(db_session_maker, workitem, env, workitem_logs)
            case _:
                return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}
    
    except Exception as e:
        return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}
    

async def get_sql_db_connection(database_name, env):
    sql_db_params = await get_sql_db_params_for_env(database_name, env)
    
    sql_db_host = sql_db_params['sql_db_host']
    sql_db_port = sql_db_params['sql_db_port']
    sql_db_name = sql_db_params['sql_db_name']
    sql_db_username = sql_db_params['sql_db_username']
    sql_db_password = sql_db_params['sql_db_password']
    
    database_url = f"mysql+aiomysql://{sql_db_username}:{sql_db_password}@{sql_db_host}:{sql_db_port}/{sql_db_name}"
    engine = create_async_engine(database_url, echo=True)
    AsyncSessionLocal = sessionmaker(engine, class_=AsyncSession, expire_on_commit=True)
    return AsyncSessionLocal


async def get_sql_db_params_for_env(database_name, env):
    sql_db_config_value = await rqt_util_service.get_value_from_env_config(database_name,env)
    return sql_db_config_value


async def execute_sql_select_query(db_session_maker, workitem, env, workitem_logs):
    workitem_request_params = workitem['workitem_request_params']
    async with db_session_maker() as session:
        try:
            select_query = workitem_request_params['query_statement']
            print(select_query)
            result = await session.execute(text(select_query))
            response_data = [dict(row._mapping) for row in result]
            workitem_response_body = {}
            if len(response_data) > 0:
                workitem_response_body = response_data[0]

            await rqt_util_service.generate_next_feed_forward(workitem, env, workitem_response_body, workitem_logs)
            return await rqt_util_service.validate_expected_and_actual_response(workitem, env, workitem_response_body, workitem_logs)  
        
        except Exception as e:
            print("Exception caused while calling : " + str(e))
            return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}


async def execute_sql_insert_query(db_session_maker, workitem, env, workitem_logs):
    workitem_request_params = workitem['workitem_request_params']
    async with db_session_maker() as session:
        try:
            insert_query = workitem_request_params['query_statement']
            await session.execute(text(insert_query))
            await session.commit()
            workitem_response_body = {}
           
            await rqt_util_service.generate_next_feed_forward(workitem, env, workitem_response_body, workitem_logs)
            return await rqt_util_service.validate_expected_and_actual_response(workitem, env, workitem_response_body, workitem_logs)  
        except Exception as e:
            print("Exception caused while calling : " + str(e))
            return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}


async def execute_sql_update_query(db_session_maker, workitem, env, workitem_logs):
    workitem_request_params = workitem['workitem_request_params']
    async with db_session_maker() as session:
        try:
            update_query = workitem_request_params['query_statement']
            await session.execute(text(update_query))
            await session.commit()
            workitem_response_body = {}
            
            await rqt_util_service.generate_next_feed_forward(workitem, env, workitem_response_body, workitem_logs)
            return await rqt_util_service.validate_expected_and_actual_response(workitem, env, workitem_response_body, workitem_logs)  
        except Exception as e:
            print("Exception caused while calling : " + str(e))
            return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}



async def execute_sql_delete_query(db_session_maker, workitem, env, workitem_logs):
    workitem_request_params = workitem['workitem_request_params']
    async with db_session_maker() as session:
        try:
            update_query = workitem_request_params['query_statement']
            await session.execute(text(update_query))
            await session.commit()
            workitem_response_body = {}
            
            await rqt_util_service.generate_next_feed_forward(workitem, env, workitem_response_body, workitem_logs)
            return await rqt_util_service.validate_expected_and_actual_response(workitem, env, workitem_response_body, workitem_logs)  
        except Exception as e:
            print("Exception caused while calling : " + str(e))
            return {"workitem_id" : workitem['workitem_id'], "env" :  env, "workitem" : workitem, "workitem_status": workitem_status_enum.FAILED, "workitem_logs" : workitem_logs}



