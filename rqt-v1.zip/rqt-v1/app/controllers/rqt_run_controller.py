from fastapi import APIRouter
from app.services import rqt_run_service
from app.models.requests.rqt_run_controller_requests import RunWorkitemRequest,RunTestcaseRequest,RunTestcaseBulkRequest
from app.models.requests.rqt_bff_controller_requests import *

router = APIRouter()

@router.post("/run-testcase")
async def run_testcase(request : RunTestcaseRequest):
    return await rqt_run_service.run_testcase(request)

@router.post("/run-workitem")
async def run_workitem(request : RunWorkitemRequest):
    return await rqt_run_service.run_workitem(request)

@router.post("/run-testcases-bulk")
async def run_testcases_bulk(request : RunTestcaseBulkRequest):
    return await rqt_run_service.run_testcases_bulk(request)
