from fastapi import APIRouter
from app.services import rqt_bff_service
from app.models.requests.rqt_bff_controller_requests import *

router = APIRouter()


@router.get("/fetch-testcase/{testcase_id}")
async def fetch_testcase(testcase_id: str):
    return await rqt_bff_service.fetch_testcase(testcase_id)


@router.post("/fetch-testcases-bulk")
async def fetch_testcases_bulk(request : FetchBulkTestcaseRequest):
    return await rqt_bff_service.fetch_testcases_bulk(request)


@router.post("/add-testcase")
async def add_new_testcase(request : AddTestcaseRequest):
    return await rqt_bff_service.add_new_testcase(request)


@router.post("/update-testcase")
async def update_testcase(request : UpdateTestcaseRequest):
    return await rqt_bff_service.update_testcase(request)


@router.get("/fetch-workitem/{workitem_id}")
async def fetch_workitem(workitem_id: str):
    return await rqt_bff_service.fetch_workitem(workitem_id)


@router.post("/fetch-workitems-bulk")
async def fetch_workitems_bulk(request : FetchBulkWorkitemRequest):
    return await rqt_bff_service.fetch_workitems_bulk(request)


@router.post("/add-workitem")
async def add_new_workitem(request : AddWorkitemRequest):
    return await rqt_bff_service.add_new_workitem(request)


@router.post("/update-workitem")
async def update_workitem(request : UpdateWorkitemRequest):
    return await rqt_bff_service.update_workitem(request)


@router.get("/fetch-env-config/{env}/{config_key}")
async def fetch_env_config(env : str, config_key : str):
    return await rqt_bff_service.fetch_env_config(env,config_key)


@router.post("/add-env-config")
async def add_new_env_config(request : AddEnvConfigRequest):
    return await rqt_bff_service.add_new_env_config(request)


@router.post("/update-env-config")
async def update_env_config(request : UpdateEnvConfigRequest):
    return await rqt_bff_service.update_env_config(request)


@router.get("/fetch-testsuite/{testsuite_id}")
async def fetch_testsuite(testsuite_id: str):
    return await rqt_bff_service.fetch_testsuite(testsuite_id)


@router.post("/add-testsuite")
async def add_new_testsuite(request : AddTestsuiteRequest):
    return await rqt_bff_service.add_new_testsuite(request)


@router.post("/update-testsuite")
async def update_testsuite(request : UpdateTestcaseRequest):
    return await rqt_bff_service.update_testsuite(request)
