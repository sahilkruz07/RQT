from app.configs.mongo_config import rqt_workitem_master

async def find_workitem_by_workitem_id_is_deleted(workitem_id : str, workitem_is_deleted : bool):
    return await rqt_workitem_master.find_one({"workitem_id": workitem_id, "workitem_is_deleted": workitem_is_deleted})


async def insert_to_db(workitem):
    await rqt_workitem_master.insert_one(workitem)


async def update_to_db(workitem_id,updated_workitem):
    update_data = {
        "$set": updated_workitem 
    }
    await rqt_workitem_master.update_one({"workitem_id": workitem_id}, update_data)
