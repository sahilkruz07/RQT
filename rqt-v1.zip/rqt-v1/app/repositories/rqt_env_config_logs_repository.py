from app.configs.mongo_config import rqt_env_config_logs

async def insert_to_db(env_config_log):
    await rqt_env_config_logs.insert_one(env_config_log)
