from app.configs.mongo_config import rqt_run_testcase_audit

async def insert_to_db(run_testcase_audit):
    await rqt_run_testcase_audit.insert_one(run_testcase_audit)
