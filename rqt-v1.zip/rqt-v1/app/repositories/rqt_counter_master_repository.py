from app.configs.mongo_config import rqt_counter_master

async def find_counter_by_counter_name(counter_name : str):
    return await rqt_counter_master.find_one({"counter_name": counter_name})

async def update_counter(counter_name : str,counter_value : int):
    update_data = {
        "$set": {"counter_value": counter_value+1} 
    }
    await rqt_counter_master.update_one({"counter_name": counter_name}, update_data)
