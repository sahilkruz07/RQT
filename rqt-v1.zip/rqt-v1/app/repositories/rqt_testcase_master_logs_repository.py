from app.configs.mongo_config import rqt_testsuite_master_logs

async def insert_to_db(testcase_audit_log):
    await rqt_testsuite_master_logs.insert_one(testcase_audit_log)


