from fastapi import FastAPI
from app.controllers import rqt_bff_controller,rqt_run_controller

app = FastAPI(debug=True)

# app.include_router(auth_controller.router, prefix="/v1/auth", tags=["Auth"])
# app.include_router(otp_controller.router, prefix="/v1/otp", tags=["OTP"])

app.include_router(rqt_bff_controller.router, prefix="/rqt-bff/v1", tags=["RQT-BFF"])
app.include_router(rqt_run_controller.router, prefix="/rqt-run/v1", tags=["RQT-RUN"])


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host = "0.0.0.0", port = 8000)